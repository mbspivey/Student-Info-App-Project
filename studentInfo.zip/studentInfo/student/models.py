from django.db import models

# Create your models here.

class Coursedetails(models.Model):
	courseid = models.IntegerField()
	coursetitle = models.CharField(max_length=100)
	coursename = models.CharField(max_length=100, default='')
	coursecode = models.IntegerField()
	coursedept = models.CharField(max_length=100)
	instructorname = models.CharField(max_length=100)


class Studentdetails(models.Model):
	firstname = models.CharField(max_length=100)
	lastname = models.CharField(max_length=100)
	major = models.CharField(max_length=100)
	year = models.CharField(max_length=100)
	gpa = models.DecimalField(max_digits=3, decimal_places=2)


class Enrollmentdata(models.Model):
	studentid = models.IntegerField(default=0)
	courseid = models.IntegerField(default=0)
	coursetitle = models.CharField(max_length=100, default='')
	coursename = models.CharField(max_length=100, default='')
	coursecode = models.IntegerField(default=0)
	coursedept = models.CharField(max_length=100, default='')
	instructorname = models.CharField(max_length=100, default='')

class Enrollmenttest(models.Model):
	studentid = models.IntegerField()
	courseid = models.IntegerField()