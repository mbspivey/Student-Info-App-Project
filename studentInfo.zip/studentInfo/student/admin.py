from django.contrib import admin
from student.models import Coursedetails, Studentdetails, Enrollmentdata, Enrollmenttest


# Register your models here.

admin.site.register(Coursedetails)

admin.site.register(Studentdetails)

admin.site.register(Enrollmentdata)

admin.site.register(Enrollmenttest)

