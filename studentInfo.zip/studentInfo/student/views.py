from django.shortcuts import render
from django.http import HttpResponse
from student.models import Coursedetails, Studentdetails, Enrollmentdata, Enrollmenttest
from django.db import connection
from django.core.paginator import Paginator
from django.template.loader import render_to_string
from django.contrib import messages
from django.contrib.auth.decorators import login_required
# Create your views here.

@login_required
def home(request):
	fcount = 0 
	socount = 0
	jcount = 0
	secount = 0
	studentcount = 0
	courselst = []
	gpatotal = float(0.0)
	
	#cursor = connection.cursor()
	#cursor.execute("SELECT COUNT(*) FROM STUDENT_STUDENTDETAILS")
	#total2 = cursor.fetchone()
	for row in Studentdetails.objects.all():
		if(row.year == "Freshman"):
			fcount = fcount + 1  
		if(row.year == "Sophomore"):
			socount = socount + 1
		if(row.year == "Junior"):
			jcount = jcount + 1
		if(row.year == "Senior"):
			secount = secount + 1
		studentcount = studentcount + 1

		gpatotal = gpatotal + float(row.gpa)
	avggpa = gpatotal/float(studentcount)

	for row in Coursedetails.objects.all():
		if(row.courseid not in courselst):
			courselst.append(row.courseid)
	coursecount = len(courselst)

	countdict = {}
	countlst = []
	for row in Enrollmentdata.objects.all():
		if(row.studentid in countdict):
			countdict[row.studentid] = countdict[row.studentid] + 1
		else:
			countdict[row.studentid] = 1

	for key in countdict:
		if countdict[key] == 3:
			countlst.append(key)
	enrolledstudentcount = len(countlst)
	#cursor.execute(SELECT COUNT(DISTINCT COURSEID) FROM STUDENT_COURSEDETAILS)
	#coursetotal = cursor.fetchone()
	return render(request, 'student/home.html', {'fcount':fcount, 'socount':socount, 
		'jcount':jcount, 'secount':secount, 'total':studentcount, 'coursecount':coursecount,
		'avggpa':avggpa, 'numenrolled':enrolledstudentcount})

@login_required
def details(request):
	studentdata = Studentdetails.objects.all()
	paginator = Paginator(studentdata, 10)
	page = request.GET.get('page')
	studentminiset = paginator.get_page(page)
	return render(request, 'student/details.html', {'data' : studentminiset})

@login_required
def enrollment(request):
	studentdata = Studentdetails.objects.all()
	coursedata = Coursedetails.objects.all()
	enrolldata = ''
	errordup = 'A student can not enroll in the same course more than once.'
	errorthree = 'Each student cannot have more than 3 enrolled courses.'
	if('studentid' in request.session):
		enrolldata = Enrollmentdata.objects.filter(studentid=request.session['studentid']) 
	if('sid' in request.GET and 'cid' not in request.GET):
		sid = int(request.GET.get('sid'))
		request.session['studentid'] = sid
		selectdata = Enrollmentdata.objects.filter(studentid=sid)
		HttpResponse('Success')
	if('sid' and 'cid' in request.GET):
		sid = int(request.GET.get('sid'))
		cid = int(request.GET.get('cid'))
		request.session['studentid'] = sid
		counter = 0    #error handling
		for row in Enrollmentdata.objects.all():   
			if(row.studentid == sid and row.courseid == cid):
				return HttpResponse('Enrolldup') 
			if(row.studentid == sid):
				counter = counter + 1
			if(counter >= 3):
				counter = 0
				#print("Error")
				return HttpResponse('Enroll3')
		# end error handling
		for row in coursedata:
			if(row.courseid == cid):
				ctitle = row.coursetitle
				cname = row.coursename
				ccode = row.coursecode
				cdept = row.coursedept
				iname = row.instructorname
		adddata = Enrollmentdata(studentid=sid, courseid=cid, coursetitle=ctitle, coursename=cname,
			coursecode=ccode, coursedept=cdept, instructorname=iname)
		adddata.save()
		enrolldata = Enrollmentdata.objects.filter(studentid=sid)
		HttpResponse('Success')	
	return render(request, 'student/enrollment.html', {'studentdata' : studentdata, 'coursedata' : coursedata, 'selectdata' : enrolldata})


@login_required
def courseinfo(request):
	coursedata = Coursedetails.objects.all()
	paginator = Paginator(coursedata, 10)
	page = request.GET.get('page')
	courseminiset = paginator.get_page(page)
	return render(request, 'student/course.html', {'cdata' : courseminiset}) 

